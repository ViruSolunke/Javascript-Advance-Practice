const display = document.getElementById("display");
const pads = document.querySelectorAll(".drum-pad");

// Play sound on click
pads.forEach(pad => {
  pad.addEventListener("click", () => {
    const audio = pad.querySelector("audio");
    audio.currentTime = 0;
    audio.play();
    display.textContent = pad.id;
  });
});

// Play sound on key press
document.addEventListener("keydown", (e) => {
  const key = e.key.toUpperCase();
  const audio = document.getElementById(key);
  if (audio) {
    audio.currentTime = 0;
    audio.play();
    display.textContent = audio.parentElement.id;
  }
});
